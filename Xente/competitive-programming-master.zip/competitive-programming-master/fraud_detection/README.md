# competitive-programming
<p>
This challenge aims to leverage the power of machine learning to aid<br>
credit fraud detection in financial instutions/service providers.

The challenge is hosted on Zindi
https://www.zindi.africa/competitions/xente-fraud-detection-challenge/
</p>
